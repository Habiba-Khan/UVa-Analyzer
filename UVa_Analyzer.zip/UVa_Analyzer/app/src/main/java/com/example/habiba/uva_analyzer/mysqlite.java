package com.example.habiba.uva_analyzer;


import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import android.widget.Toast;

/**
 * Created by HABIBA on 5/6/2017.
 */

public class mysqlite extends SQLiteOpenHelper {


    private static final String DATABASE_NAME = "my_uvaAnalyzer.db";
    private static final String TABLE_NAME = "RANKING";
    private static final String TABLE_PROBLEMS = "PROBLEMS";
    private static final String COLUMN1 = "ID";
    private static final String COLUMN2 = "NAME";
    private static final String COLUMN3 = "RANK";
    private static final String COLUMN4 = "AC";

    private static final String COLUMN5 = "PNO";
    private static final String COLUMN6 = "PNAME";
    private static final String COLUMN7 = "TYPE";
    private static final String COLUMN8 = "HINT";
    private static final String COLUMN9 = "CIN";
    private static final String COLUMN10 = "COUT";



    public mysqlite(Context context) {
        super(context, DATABASE_NAME, null, 1);
    }

    @Override
    public void onCreate(SQLiteDatabase sqLiteDatabase) {
        String quary = "CREATE TABLE "+TABLE_NAME+ "("
                +COLUMN1+ " INTEGER , "
                +COLUMN2+ " TEXT, "
                +COLUMN3+ " INTEGER, "
                +COLUMN4+ " INTEGER "+ ");";
        sqLiteDatabase.execSQL(quary);
        String quary2 = "CREATE TABLE "+TABLE_PROBLEMS+ "("
                +COLUMN5+ " INTEGER , "
                +COLUMN6+ " TEXT, "
                +COLUMN7+ " TEXT, "
                +COLUMN8+ " TEXT, "
                +COLUMN9+ " TEXT, "
                +COLUMN10+ " TEXT "+ ");";
        sqLiteDatabase.execSQL(quary2);
    }

    @Override
    public void onUpgrade(SQLiteDatabase sqLiteDatabase, int i, int i1) {
        sqLiteDatabase.execSQL("DROP TABLE IF EXISTS "+TABLE_NAME);
        sqLiteDatabase.execSQL("DROP TABLE IF EXISTS "+TABLE_PROBLEMS);
        onCreate(sqLiteDatabase);
    }

    public String addtotable(String id, String name, int rank, int ac){
        SQLiteDatabase sqLiteDatabase = getWritableDatabase();
        ContentValues contentValues = new ContentValues();
        contentValues.put(COLUMN1,id);
        contentValues.put(COLUMN2,name);
        contentValues.put(COLUMN3,rank);
        contentValues.put(COLUMN4,ac);
        long checker = sqLiteDatabase.insert(TABLE_NAME,null,contentValues);

        if(checker == -1){
            return "false";
        }
        else
            return "true";
    }

    public boolean addProblem(String id, String name, String type, String hints,String cin, String cout){
        SQLiteDatabase sqLiteDatabase = getWritableDatabase();
        ContentValues contentValues = new ContentValues();
        contentValues.put(COLUMN5,id);
        contentValues.put(COLUMN6,name);
        contentValues.put(COLUMN7,type);
        contentValues.put(COLUMN8,hints);
        contentValues.put(COLUMN9,cin);
        contentValues.put(COLUMN10,cout);
        long checker = sqLiteDatabase.insert(TABLE_PROBLEMS,null,contentValues);

        if(checker == -1){
            return false;
        }
        else
            return true;
    }

    public Cursor display(String s){
        SQLiteDatabase sqLiteDatabase = getReadableDatabase();
        Cursor res ;
        //res = sqLiteDatabase.rawQuery("SELECT "+s+" FROM "+TABLE_NAME+ " order by RANK asc ",null);
        res = sqLiteDatabase.rawQuery("SELECT * FROM " + TABLE_NAME +" ORDER BY "+COLUMN4+ " DESC" , new String[] {});
        return res;
    }

    public String update(String id, String name, int rank, int ac){
        SQLiteDatabase sqLiteDatabase = getWritableDatabase();
        ContentValues contentValues = new ContentValues();
        //contentValues.put(COLUMN1,id);
        contentValues.put(COLUMN2,name);
        contentValues.put(COLUMN3,rank);
        contentValues.put(COLUMN4,ac);
        long checker = sqLiteDatabase.update(TABLE_NAME,contentValues,"ID = ?", new String[]{id});

        if(checker == -1){
            return "false";
        }
        else
            return "true";
    }

    public int delete(String id){
        SQLiteDatabase sqLiteDatabase = getWritableDatabase();
        return sqLiteDatabase.delete(TABLE_NAME,"ID = ?",new String[]{id});
    }
}
