package com.example.habiba.uva_analyzer;

import android.content.Intent;
import android.database.Cursor;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.support.v7.widget.SearchView;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.ListAdapter;
import android.widget.ListView;
import android.widget.Toast;

public class Easy_problem extends AppCompatActivity {

    ListView lv;
    SearchView sv;
    final sqliteProblem my = new sqliteProblem(this);
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_easy_problem);
        lv = (ListView)findViewById(R.id.Listview1);
        // sv = (SearchView) findViewById(R.id.searchView);
        display();
    }

    public void display() {
        Cursor dp = my.display("easy");
        if (dp.getCount() == 0) {
            Toast.makeText(getApplicationContext(), "List is empty", Toast.LENGTH_SHORT).show();
            return;
        }
        dp.moveToFirst();
        String[] pno = new String[dp.getCount()];

        int n = 0;
        do {
            pno[n] = dp.getString(0).toString() +"  --  "+ dp.getString(1).toString();
            n++;
        } while (dp.moveToNext());

        final ListAdapter listAdapter = new ArrayAdapter<String>(this, R.layout.support_simple_spinner_dropdown_item, pno);
        lv.setAdapter(listAdapter);
        lv.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> adapterView, View view, int i, long l) {
                //Toast.makeText(getApplicationContext(),lv.getItemAtPosition(i).toString(),Toast.LENGTH_SHORT).show();
                Intent intent = new Intent(Easy_problem.this,problemDetailsDisplay.class);
                intent.putExtra("pno",lv.getItemAtPosition(i).toString());
                startActivity(intent);

            }
        });
    }

}
