package com.example.habiba.uva_analyzer;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;

public class Login extends AppCompatActivity {
    EditText user,pass;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login);
    }

    public void login(View view){
        user = (EditText)findViewById(R.id.editText3);
        pass = (EditText)findViewById(R.id.editText4);

        if((user.getText().toString().equals("habiba")) && pass.getText().toString().equals("123")){
            user.setText("");
            pass.setText("");
            Intent intent = new Intent(Login.this,SetProblem.class);
            startActivity(intent);
        }
    }
}
